package ships;

import projectiles.Projectile;
import utils.Position;

public class ShooterShip extends InvaderShip {
  /**
   * Constructs a ShooterShip
   * @param p The initial position
   * @param armor The initial armor level
   */
	public ShooterShip(Position p, int armor) {
	}

	public Projectile[] fire() {
		return null;
	}

	@Override
	public String imgPath() {
		return "res/monster.png";

	}

	@Override
	public int getPoints() {
		return 50;
	}
}
