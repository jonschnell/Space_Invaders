package ships;

import projectiles.Projectile;
import utils.Position;

public class MultiShooterShip extends ShooterShip {
	public static final int NUM_CANNONS = 5;
	public static final double SPREAD = 0.25;

  /**
   * Constructs a MultiShooterShip
   * @param p The initial position
   * @param armor The initial armor level
   */
	public MultiShooterShip(Position p, int armor) {
	}

  /**
   * Fires NUM_CANNONS projectiles, that spread out as they fall
   * @return An array of projectiles
   */
	public Projectile[] fire() {
          /*
           * Hint, to get a spread, second parameter to Projectile() should
           * be something like (i - (NUM_CANNONS / 2)) * SPREAD
           */
                return null;
	}

	@Override
	public String imgPath() {
		return "res/monster3.png";
	}
}
